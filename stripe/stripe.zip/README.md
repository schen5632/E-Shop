# E-Shop

This is a full-stack e-commerce web application built using Java, Spring Boot, React, and MySQL with REST APIs for products and orders. It also contains payment
processing using Stripe API and user authentication using Firebase.

![image](https://user-images.githubusercontent.com/93620334/228695471-0aa42b64-10c7-4fc6-a0ce-6e4ed3025fb7.png)

![image](https://user-images.githubusercontent.com/93620334/228695514-f594e86d-a7d3-4e9f-9e6e-015ff4510b38.png)

![image](https://user-images.githubusercontent.com/93620334/228695991-8ba64722-95b1-43e5-82d7-c5e39af2e7bb.png)

![image](https://user-images.githubusercontent.com/93620334/228696055-e82588ca-fe2b-4ab5-9f70-40482f83efb8.png)


